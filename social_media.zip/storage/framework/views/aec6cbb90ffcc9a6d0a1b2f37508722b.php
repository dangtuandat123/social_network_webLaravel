
<nav class="navbar navbar-expand-lg fixed-top" style="background: linear-gradient(135deg, rgba(255,255,255,0.95) 0%, rgba(240,244,255,0.95) 100%); backdrop-filter: blur(20px); border-bottom: 1px solid rgba(99, 102, 241, 0.1); box-shadow: 0 4px 20px rgba(99, 102, 241, 0.08);">
    <div class="container">
        
        <a class="navbar-brand d-flex align-items-center" href="<?php echo e(route('home')); ?>" style="font-weight: 800; font-size: 1.5rem;">
            <div style="width: 40px; height: 40px; background: var(--gradient-primary); border-radius: 12px; display: flex; align-items: center; justify-content: center; margin-right: 10px; box-shadow: 0 4px 15px rgba(99, 102, 241, 0.3);">
                <i class="ri-bubble-chart-fill" style="color: white; font-size: 1.3rem;"></i>
            </div>
            <span class="text-gradient">Social</span>
        </a>

        
        <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMain">
            <i class="ri-menu-3-line" style="font-size: 1.5rem; color: var(--primary);"></i>
        </button>

        
        <div class="collapse navbar-collapse" id="navbarMain">
            <ul class="navbar-nav ms-auto align-items-center gap-2">
                <?php if(Auth::check()): ?>
                    
                    <li class="nav-item">
                        <a href="<?php echo e(route('home')); ?>" class="nav-link px-3 py-2 rounded-pill <?php echo e(request()->routeIs('home') ? 'active-nav' : ''); ?>" style="font-weight: 600; transition: all 0.3s;">
                            <i class="ri-home-4-line me-1"></i> Trang chủ
                        </a>
                    </li>
                    
                    
                    <li class="nav-item">
                        <a href="<?php echo e(route('profile')); ?>" class="nav-link px-3 py-2 rounded-pill <?php echo e(request()->routeIs('profile') ? 'active-nav' : ''); ?>" style="font-weight: 600; transition: all 0.3s;">
                            <i class="ri-user-line me-1"></i> Hồ sơ
                        </a>
                    </li>

                    
                    <li class="nav-item dropdown ms-2">
                        <a href="#" class="nav-link dropdown-toggle d-flex align-items-center p-0" data-bs-toggle="dropdown" style="gap: 8px;">
                            <div style="position: relative;">
                                <?php if(Auth::user()->avatar): ?>
                                    <img src="<?php echo e(asset('storage/' . Auth::user()->avatar)); ?>" 
                                        class="rounded-circle" 
                                        style="width: 42px; height: 42px; object-fit: cover; border: 3px solid transparent; background: linear-gradient(white, white) padding-box, var(--gradient-primary) border-box;" 
                                        alt="Avatar">
                                <?php else: ?>
                                    <img src="<?php echo e(asset('template_assets/images/user/01.jpg')); ?>" 
                                        class="rounded-circle" 
                                        style="width: 42px; height: 42px; object-fit: cover; border: 3px solid transparent; background: linear-gradient(white, white) padding-box, var(--gradient-primary) border-box;" 
                                        alt="Avatar">
                                <?php endif; ?>
                                <span style="position: absolute; bottom: 2px; right: 2px; width: 10px; height: 10px; background: var(--success); border-radius: 50%; border: 2px solid white;"></span>
                            </div>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end shadow-lg border-0 mt-2" style="min-width: 240px; border-radius: 18px; overflow: hidden; padding: 0;">
                            <li style="background: linear-gradient(135deg, #6366F1 0%, #EC4899 100%); padding: 1rem; margin: 0;">
                                <div style="color: white; font-weight: 700;"><?php echo e(Auth::user()->name); ?></div>
                                <small style="color: rgba(255,255,255,0.8);"><?php echo e(Auth::user()->email); ?></small>
                            </li>
                            <li>
                                <a class="dropdown-item py-2 px-3" href="<?php echo e(route('profile')); ?>" style="font-weight: 500;">
                                    <i class="ri-user-settings-line me-2" style="color: #6366F1;"></i> Trang cá nhân
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item py-2 px-3" href="#" style="font-weight: 500;">
                                    <i class="ri-settings-3-line me-2" style="color: #14B8A6;"></i> Cài đặt
                                </a>
                            </li>
                            <li><hr class="dropdown-divider my-1"></li>
                            <li>
                                <form action="<?php echo e(route('logout')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="dropdown-item py-2 px-3" style="font-weight: 500; color: #EF4444;">
                                        <i class="ri-logout-box-line me-2"></i> Đăng xuất
                                    </button>
                                </form>
                            </li>
                        </ul>
                    </li>
                <?php else: ?>
                    
                    <li class="nav-item">
                        <a href="<?php echo e(route('login')); ?>" class="btn btn-primary px-4 py-2" style="font-weight: 600;">
                            <i class="ri-login-box-line me-1"></i> Đăng nhập
                        </a>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>


<div class="nav-spacer"></div>

<style>
    .nav-spacer { height: 70px; }
    .nav-link { color: #64748B; transition: color 0.2s; }
    .nav-link:hover { color: #6366F1; }
    .active-nav { 
        background: linear-gradient(135deg, rgba(99, 102, 241, 0.15) 0%, rgba(236, 72, 153, 0.1) 100%); 
        color: #6366F1 !important; 
    }
    .dropdown-item:hover { background: rgba(99, 102, 241, 0.08); }
    
    @media (max-width: 768px) {
        .nav-spacer { height: 60px; }
        .navbar { padding: 0.5rem 0; }
        .navbar-brand { font-size: 1.25rem !important; }
        .navbar-brand > div:first-child { 
            width: 32px !important; 
            height: 32px !important; 
            border-radius: 10px !important;
        }
        .navbar-brand i { font-size: 1.1rem !important; }
        .nav-link { font-size: 0.9rem; padding: 0.5rem 0.75rem !important; }
        .dropdown-toggle img, .dropdown-toggle .rounded-circle { 
            width: 36px !important; 
            height: 36px !important; 
        }
    }
    
    @media (max-width: 480px) {
        .nav-spacer { height: 55px; }
        .navbar-brand span { display: none; }
        .nav-item .nav-link span { display: none; }
    }
</style>
<?php /**PATH D:\Workspace\Web laravel\social_media\resources\views/layouts/header.blade.php ENDPATH**/ ?>